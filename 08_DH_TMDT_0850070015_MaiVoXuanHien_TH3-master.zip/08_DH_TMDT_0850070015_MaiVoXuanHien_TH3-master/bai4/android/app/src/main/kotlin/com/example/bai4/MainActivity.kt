package com.example.bai4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
