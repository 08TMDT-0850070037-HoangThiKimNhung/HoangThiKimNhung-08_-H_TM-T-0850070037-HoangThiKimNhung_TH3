package com.example.bai3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
